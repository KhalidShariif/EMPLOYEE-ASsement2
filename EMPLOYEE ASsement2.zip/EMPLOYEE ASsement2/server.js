
const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();
app.use(express.json());

const logger = require("./middleware/logger");
app.use(logger);

app.use("/api/employees", require("./routes/employee.routes"));
app.use("/api/departments", require("./routes/department.routes"));
app.use("/api/projects", require("./routes/project.routes"));
app.use("/api/attendance", require("./routes/attendance.routes"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log("Employees server running on port " + PORT)
);
