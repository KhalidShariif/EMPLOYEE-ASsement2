
    const mongoose = require("mongoose");
    const schema = new mongoose.Schema({
      employeeName: String,
      date: Date,
      status: String
    });
    module.exports = mongoose.model("Attendance", schema);
    