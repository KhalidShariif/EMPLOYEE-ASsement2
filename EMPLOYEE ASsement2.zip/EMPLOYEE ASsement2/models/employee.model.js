
    const mongoose = require("mongoose");
    const schema = new mongoose.Schema({
      name: String,
      email: String,
      position: String,
      salary: Number
    });
    module.exports = mongoose.model("Employee", schema);
    