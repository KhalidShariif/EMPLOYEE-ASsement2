
    const mongoose = require("mongoose");
    const schema = new mongoose.Schema({
      title: String,
      status: String,
      deadline: Date
    });
    module.exports = mongoose.model("Project", schema);
    