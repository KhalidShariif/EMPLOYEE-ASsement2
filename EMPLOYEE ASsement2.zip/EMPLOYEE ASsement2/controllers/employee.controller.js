
const Employee = require("../models/employee.model");

exports.create = async (req, res) => {
  try {
    const data = await Employee.create(req.body);
    res.status(201).json(data);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getAll = async (req, res) => {
  res.json(await Employee.find());
};

exports.getOne = async (req, res) => {
  res.json(await Employee.findById(req.params.id));
};

exports.update = async (req, res) => {
  res.json(await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true }));
};

exports.remove = async (req, res) => {
  await Employee.findByIdAndDelete(req.params.id);
  res.json({ message: "Employee deleted" });
};
